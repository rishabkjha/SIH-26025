#include <Arduino.h>
#include "IntegratedAlgorithm.h"
#include "LoRa_Packetizer.h"
#include "LoRaManager.h"

// Hardware Pin Definitions
#define IMU_SDA_PIN     21
#define IMU_SCL_PIN     22
#define VIBE_PIN        25
#define GPS_RX_PIN      16
#define GPS_TX_PIN      17

#define LORA_SS_PIN     5
#define LORA_RST_PIN    27
#define LORA_DIO0_PIN   26
#define LORA_FREQ_HZ    433E6 // Change to 868E6 or 433E6 if required by region

// Module Instantiations
IntegratedAlgorithm algo(IMU_SDA_PIN, IMU_SCL_PIN, VIBE_PIN, GPS_RX_PIN, GPS_TX_PIN);
LoRaPacketizer packetizer;
LoRaManager lora(LORA_FREQ_HZ, LORA_SS_PIN, LORA_RST_PIN, LORA_DIO0_PIN);

// Timer for rate-limiting LoRa transmissions
uint32_t lastTxTime = 0;
const uint32_t TX_INTERVAL_MS = 1000; // 1 Hz transmission rate

void setup() {
    Serial.begin(115200);
    while (!Serial && millis() < 3000); // USB CDC connection delay

    Serial.println(F("--- Initializing High-Precision System ---"));

    // 1. Initialize IMU, Vibration Sensor, and GPS Telemetry
    algo.begin();

    // 2. Initialize LoRa Module
    if (!lora.begin(/*txPower=*/17, /*spreadingFactor=*/7, /*bandwidth=*/125E3)) {
        Serial.println(F("Critical Error: LoRa hardware setup failed! Halting..."));
        while (1); 
    }

    Serial.println(F("Setup complete. Streaming data & waiting for High Precision GPS..."));
}

void loop() {
    // Continuously process sensor metrics (IMU, Vibration, and GPS UART stream)
    algo.update();

    // Debug print algorithm outputs to Serial Monitor (internal rate limit at 5Hz)
    algo.printData();

    // Rate-limited LoRa Transmission
    if (millis() - lastTxTime >= TX_INTERVAL_MS) {
        lastTxTime = millis();

        // Feed algorithm data into binary packetizer and transmit
        packetizer.packData(algo);
        bool txStatus = lora.sendPacket(packetizer);

        if (txStatus) {
            Serial.print(F("[LoRa TX] Packet Sent Successfully! Size: "));
            Serial.print(packetizer.getPacketSize());
            Serial.println(F(" bytes."));
        } else {
            Serial.println(F("[LoRa TX Error] Packet transmission failed."));
        }
    }

    // Small yield to allow CPU background tasks & prevent tight loop starvation
    delay(1);
}