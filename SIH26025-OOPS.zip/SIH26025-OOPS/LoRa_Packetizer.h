/*
#include <Arduino.h>
#include <LoRa.h>
#include "IntegratedAlgorithm.h"
#include "LoRa_Packetizer.h"

IntegratedAlgorithm systemAlgo;
LoRaPacketizer loraPacketizer;

void setup() {
    Serial.begin(115200);
    systemAlgo.begin();

    // Initialize LoRa Hardware (e.g., 915MHz or 868MHz depending on region)
    if (!LoRa.begin(915E6)) {
        Serial.println("LoRa initialization failed!");
        while (1);
    }
}

void loop() {
    systemAlgo.update();

    // Send packet via LoRa every 1 second (or preferred interval)
    static uint32_t lastTxTime = 0;
    if (millis() - lastTxTime >= 1000) {
        lastTxTime = millis();

        // 1. Pack algorithm outputs into binary payload
        loraPacketizer.packData(systemAlgo);

        // 2. Feed directly into LoRa transmission
        LoRa.beginPacket();
        LoRa.write(loraPacketizer.getBuffer(), loraPacketizer.getPacketSize());
        LoRa.endPacket();

        Serial.println("Packet transmitted over LoRa!");
    }
}
*/

#ifndef LORA_PACKETIZER_H
#define LORA_PACKETIZER_H

#include <Arduino.h>
#include "IntegratedAlgorithm.h"

// Ensure strict byte alignment without compiler padding
#pragma pack(push, 1)
struct SensorPacket {
    // 1. Position Data (8 bytes)
    int32_t latScaled;          // Latitude * 1e6 (6 decimal places accuracy)
    int32_t lonScaled;          // Longitude * 1e6 (6 decimal places accuracy)
    int32_t altScaled;          // Altitude * 1e6 (6 decimal places accuracy)
    
    // 2. Displacements in mm (6 bytes)
    int16_t displacementX_mm;   // Range: -32,768 to +32,767 mm (~32m)
    int16_t displacementY_mm;   // Range: -32,768 to +32,767 mm (~32m)
    int16_t displacementZ_mm;   // Range: -32,768 to +32,767 mm (~32m)

    // 3. Accelerations in mm/s^2 (8 bytes)
    int16_t accX_mmss2;
    int16_t accY_mmss2;
    int16_t accZ_mmss2;
    uint16_t resultantAccel;

    // 4. Rotation Rates in deg/s (8 bytes)
    int16_t rateRollDegS;       // Scaled by 10 (e.g., 12.3 deg/s -> 123)
    int16_t ratePitchDegS;      // Scaled by 10
    int16_t rateYawDegS;        // Scaled by 10

    // 5. Angles in degrees (6 bytes)
    int16_t angleRoll;          // Scaled by 10 (e.g., 45.2 deg -> 452)
    int16_t anglePitch;         // Scaled by 10
    int16_t angleYaw;           // Scaled by 10

    // 6. System Status (2 bytes)
    uint8_t vibrationDetected : 1; // 1 bit flag
    uint8_t isHighPrecision   : 1; // 1 bit flag
    uint8_t reserved          : 6; // Padding bits for alignment
    uint8_t packetSequence;        // Rolling counter to track dropped packets
};
#pragma pack(pop)

class LoRaPacketizer {
private:
    SensorPacket _packet;
    uint8_t _sequenceNumber = 0;

public:
    LoRaPacketizer() {
        memset(&_packet, 0, sizeof(SensorPacket));
    }

    // Populate binary packet directly from IntegratedAlgorithm output
    const SensorPacket& packData(const IntegratedAlgorithm &algo) {
        // GPS Data
        _packet.latScaled = (int32_t)(algo.lat * 1e6);
        _packet.lonScaled = (int32_t)(algo.lon * 1e6);
        _packet.altScaled = (int32_t)(algo.alt * 1e6);

        // Displacements (clamped to int16_t range)
        _packet.displacementX_mm = (int16_t)constrain(algo.displacementX_mm, -32768.0f, 32767.0f);
        _packet.displacementY_mm = (int16_t)constrain(algo.displacementY_mm, -32768.0f, 32767.0f);
        _packet.displacementZ_mm = (int16_t)constrain(algo.displacementZ_mm, -32768.0f, 32767.0f);

        // Accelerations
        _packet.accX_mmss2 = (int16_t)constrain(algo.AccX_mmss2, -32768.0f, 32767.0f);
        _packet.accY_mmss2 = (int16_t)constrain(algo.AccY_mmss2, -32768.0f, 32767.0f);
        _packet.accZ_mmss2 = (int16_t)constrain(algo.AccZ_mmss2, -32768.0f, 32767.0f);
        _packet.resultantAccel = (uint16_t)constrain(algo.resultantAccel, 0.0f, 65535.0f);

        // Rotation Rates (Scaled x10 for 0.1 deg/s resolution)
        _packet.rateRollDegS  = (int16_t)constrain(algo.RateRollDegS * 10.0f, -32768.0f, 32767.0f);
        _packet.ratePitchDegS = (int16_t)constrain(algo.RatePitchDegS * 10.0f, -32768.0f, 32767.0f);
        _packet.rateYawDegS   = (int16_t)constrain(algo.RateYawDegS * 10.0f, -32768.0f, 32767.0f);

        // Angles (Scaled x10 for 0.1 deg resolution)
        _packet.angleRoll  = (int16_t)constrain(algo.AngleRoll * 10.0f, -32768.0f, 32767.0f);
        _packet.anglePitch = (int16_t)constrain(algo.AnglePitch * 10.0f, -32768.0f, 32767.0f);
        _packet.angleYaw   = (int16_t)constrain(algo.AngleYaw * 10.0f, -32768.0f, 32767.0f);

        // Status Flags & Sequence Counter
        _packet.vibrationDetected = algo.vibrationDetected ? 1 : 0;
        _packet.isHighPrecision   = 1; // Updated when this function is called
        _packet.packetSequence    = _sequenceNumber++;

        return _packet;
    }

    // Returns pointer to raw bytes for direct buffer feed (e.g. LoRa.write)
    const uint8_t* getBuffer() const {
        return reinterpret_cast<const uint8_t*>(&_packet);
    }

    // Size of the raw packet payload in bytes
    size_t getPacketSize() const {
        return sizeof(SensorPacket);
    }

    // Convenient print tool for debugging packed data
    void printPackedPacket() const {
        Serial.println(F("--- Packed LoRa Payload ---"));
        Serial.print(F("Payload Size : ")); Serial.print(getPacketSize()); Serial.println(F(" bytes"));
        Serial.print(F("Sequence No. : ")); Serial.println(_packet.packetSequence);
        Serial.print(F("Packed Lat/Lon: ")); Serial.print(_packet.latScaled); Serial.print(F(" / ")); Serial.println(_packet.lonScaled);
        Serial.print(F("Packed Disp X/Y/Z: ")); Serial.print(_packet.displacementX_mm); Serial.print(F(", "));
        Serial.print(_packet.displacementY_mm); Serial.print(F(", ")); Serial.println(_packet.displacementZ_mm);
        Serial.print(F("Packed Angles R/P/Y: ")); Serial.print(_packet.angleRoll / 10.0f); Serial.print(F(", "));
        Serial.print(_packet.anglePitch / 10.0f); Serial.print(F(", ")); Serial.println(_packet.angleYaw / 10.0f);
        Serial.println(F("---------------------------"));
    }
};

#endif // LORA_PACKETIZER_H